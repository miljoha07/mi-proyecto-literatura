package gutendex_api_project;

import java.util.List;

public class BookService {
    public static void searchBookByTitle(String title) {
        // Implementación para buscar libro por título usando HttpClient
    }

    public static void listAllBooks() {
        // Implementación para listar todos los libros
    }

    public static void showBooksStatsByLanguage(String language) {
        // Implementación para mostrar estadísticas de libros por idioma
    }
}