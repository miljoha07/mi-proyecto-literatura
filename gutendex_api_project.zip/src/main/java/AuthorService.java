package gutendex_api_project;

public class AuthorService {
    public static void listAllAuthors() {
        // Implementación para listar todos los autores
    }

    public static void listAuthorsAliveInYear(int year) {
        // Implementación para listar autores vivos en un año específico
    }
}